import React from 'react';

function Footer(){
    return(
        <footer className="text-center">
            <p className="text-light"> Copyright@2019 | All Right Reserved</p>
        </footer>
    )
}

export default Footer;